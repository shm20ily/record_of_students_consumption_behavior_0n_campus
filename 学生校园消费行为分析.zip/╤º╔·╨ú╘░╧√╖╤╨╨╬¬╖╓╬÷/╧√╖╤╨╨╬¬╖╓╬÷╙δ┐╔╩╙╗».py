import pandas as pd
from pyecharts import options as opts
from pyecharts.charts import Pie
from pyecharts.charts import Bar
from pyecharts.commons.utils import JsCode
from pyecharts.charts import Grid, Liquid
from pyecharts.charts import Line
from pyecharts.charts import Page
import pymongo

data = pd.read_csv('校园消费行为数据.csv', encoding='gbk')
print(data.to_dict('records'))
client = pymongo.MongoClient('localhost', 27017)  # 创建连接
Song_Info_book = client['Consume_Info']  # 创建名为 "Consume_Info" 的数据库
Info_Sheet = Song_Info_book['Consume_Info_Sheet']  # 在"Consume_Info"数据库中建表"Consume_Info_Sheet"
Info_Sheet.insert_many(data.to_dict('records'))  # 将数据写入MongoDB中

canteen = data.loc[:, '消费地点'].value_counts()[:5]
canteen_count = pd.DataFrame({'canteen': canteen.index, 'count': canteen.values})


def canteen_range(x):
    if x <= 25000:
        return '第三食堂'
    elif x <= 30000:
        return '第四食堂'
    elif x <= 55000:
        return '第一食堂'
    elif x <= 60000:
        return '第五食堂'
    else:
        return '第二食堂'


canteen_count['canteen_range'] = canteen_count['count'].apply(lambda x: canteen_range(x))
canteen_cut_num = canteen_count.groupby('canteen_range')['count'].sum()
# print(canteen_cut_num)

pie = Pie(init_opts=opts.InitOpts(width='1350px', height='750px'))
pie.add(
    "",
    [list(z) for z in zip(canteen_cut_num.index.tolist(), canteen_cut_num.values.tolist())],
    radius=["40%", "55%"],
    label_opts=opts.LabelOpts(
        position="outside",
        formatter="{a|{a}}{abg|}\n{hr|}\n {b|{b}: }{c}  {per|{d}%}  ",
        background_color="#eee",
        border_color="#aaa",
        border_width=1,
        border_radius=4,
        rich={
            "a": {"color": "#999", "lineHeight": 22, "align": "center"},
            "abg": {
                "backgroundColor": "#e3e3e3",
                "width": "100%",
                "align": "right",
                "height": 22,
                "borderRadius": [4, 4, 0, 0],
            },
            "hr": {
                "borderColor": "#aaa",
                "width": "100%",
                "borderWidth": 0.5,
                "height": 0,
            },
            "b": {"fontSize": 16, "lineHeight": 33},
            "per": {
                "color": "#eee",
                "backgroundColor": "#334455",
                "padding": [2, 4],
                "borderRadius": 2,
            },
        },
    ),
)
pie.render("食堂就餐人次占比饼图.html")

# 对data中消费时间数据进行时间格式转换，转换后可作运算，coerce将无效解析设置为NaT
data.loc[:, '消费时间'] = pd.to_datetime(data.loc[:, '消费时间'], format='%Y-%m-%d %H:%M', errors='coerce')
# 创建一个消费星期列，根据消费时间计算出消费时间是星期几，Monday=1, Sunday=7
data['消费星期'] = data['消费时间'].dt.dayofweek + 1

# 以周一至周五作为工作日，周六日作为非工作日，拆分为两组数据
work_day_query = data.loc[:, '消费星期'] <= 5
unwork_day_query = data.loc[:, '消费星期'] > 5

work_day_data = data.loc[work_day_query, :]
unwork_day_data = data.loc[unwork_day_query, :]

# 以时间段作为x轴，同一时间段出现的次数和作为y轴，作曲线图
time = []
for i in range(24):
    time.append('{:02d}:00'.format(i))
pd.set_option('display.max_columns', None)

# 计算工作日消费时间对应的各时间的消费总次数
work_day_times = []
for i in range(24):
    work_day_times.append(work_day_data['消费时间'].apply(str).str.contains(' {:02d}:'.format(i)).sum())

# 计算非工作日消费时间对应的各时间的消费总次数
unwork_day_times = []
for i in range(24):
    unwork_day_times.append(unwork_day_data['消费时间'].apply(str).str.contains(' {:02d}:'.format(i)).sum())

seri_work_times = pd.Series(work_day_times, index=time)
seri_unwork_times = pd.Series(unwork_day_times, index=time)

lin = Line(init_opts=opts.InitOpts(width='1350px', height='750px'))
lin.add_xaxis(time)
lin.add_yaxis("工作日", seri_work_times, areastyle_opts=opts.AreaStyleOpts(opacity=0.5))
lin.add_yaxis("非工作日", seri_unwork_times, areastyle_opts=opts.AreaStyleOpts(opacity=0.5))
lin.set_global_opts(title_opts=opts.TitleOpts(title="工作日与非工作日消费面积图"))
lin.render("工作日与非工作日消费面积图.html")

# 计算人均刷卡频次(总刷卡次数/学生总人数)
cost_count = data['消费时间'].count()
student_count = data['校园卡号'].value_counts(dropna=False).count()
average_cost_count = int(round(cost_count / student_count))
# print(average_cost_count)

# 计算人均消费额(总消费金额/学生总人数)
cost_sum = data['消费金额'].sum()
average_cost_money = int(round(cost_sum / student_count))
# print(average_cost_money)

# # 随机分析10个专业，不同性别的学生消费特点
data_set = data.groupby('专业名称')['性别'].value_counts().head(20)
# 将多级索引的series转化为DataFrame
data_set_df = data_set.unstack()
# print(data_set_df)

bar = Bar(init_opts=opts.InitOpts(width='1350px', height='750px'))
bar.add_xaxis(data_set_df.index.tolist())
bar.add_yaxis("女", data_set_df.loc[:, '女'].values.tolist())
bar.add_yaxis("男", data_set_df.loc[:, '男'].values.tolist())
bar.set_global_opts(
    title_opts=opts.TitleOpts(title="随机10个专业，不同性别的学生消费特点"),
    yaxis_opts=opts.AxisOpts(name="人数"),
    xaxis_opts=opts.AxisOpts(name="专业名称"),
)
bar.render("随机10个专业不同性别的学生消费特点.html")

# 选出消费总额最低的500名学生的消费信息
data_500 = data.groupby('校园卡号').sum()[['消费金额']]
data_500.sort_values(by=['消费金额'], ascending=True, inplace=True, na_position='first')
data_500 = data_500.head(500)
data_500_index = data_500.index.values
data_500 = data[data['校园卡号'].isin(data_500_index)]
# print(data_500.head(10))

# 取出最低消费500人的最频繁的消费地点，并添加一列 最常消费地点
data['最常消费地点'] = data.groupby('校园卡号')['消费地点'].transform(lambda x: x.value_counts().index[0])

data_max_place = data['最常消费地点'].value_counts(dropna=False)
# print(data_max_place)
canteen_count = data_max_place[:5].sum() / data_max_place.sum()
other_count = data_max_place[5:].sum() / data_max_place.sum()

l1 = (
    Liquid()
    .add("lq", [canteen_count], center=["60%", "50%"])
    .set_global_opts(title_opts=opts.TitleOpts(title="最常消费食堂与其他地点的比例情况"))
)
l2 = Liquid().add(
    "lq",
    [other_count],
    center=["25%", "50%"],
    label_opts=opts.LabelOpts(
        font_size=60,
        formatter=JsCode(
            """function (param) {
                    return (Math.floor(param.value * 10000) / 100) + '%';
                }"""),
        position="inside"),
)
grid = Grid().add(l1, grid_opts=opts.GridOpts()).add(l2, grid_opts=opts.GridOpts())
grid.render("最常消费食堂与其他地点的比例情况.html")

page = Page(layout=Page.DraggablePageLayout)
page.add(
    bar,
    pie,
    lin,
    grid,
)
page.render('可视化大屏.html')
# page.save_resize_html("可视化大屏.html",
#                       cfg_file="chart_config.json",
#                       dest="mycharts_demo.html")
